XionERP logo pack
=================

Use the logos exactly as supplied.

  - Do not redraw, recolour, stretch, rotate, outline or add effects to a logo.
  - Do not change the proportions of a logo or separate the mark from its name.
  - Leave clear space around a logo at least equal to the height of the letter "X".
  - Use the colour logo on light backgrounds and the "for dark backgrounds"
    version on dark ones. Do not place a logo on a busy or low-contrast image.
  - Do not combine a Xion logo with your own logo to make a new logo.
  - Refer to the products as XionERP, XionConnect, Xion Webstore and XionTransform.

Questions about using the logos: reply to your welcome email.

(c) AutomateXion Trading and Services, Muscat, Oman.
